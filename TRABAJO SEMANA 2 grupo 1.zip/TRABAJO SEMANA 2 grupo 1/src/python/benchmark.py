import csv
from time import perf_counter_ns

# Búsqueda Lineal (Código base de la guía)
def busqueda_lineal(a, x):
    ops = 0
    for i, valor in enumerate(a):
        ops += 1 # Contador de operación dominante
        if valor == x:
            return i, ops
    return -1, ops

# Búsqueda Binaria (Código base de la guía)
def busqueda_binaria(a, x):
    izq, der, ops = 0, len(a) - 1, 0
    while izq <= der:
        medio = izq + (der - izq) // 2
        ops += 1 # Contador de operación dominante
        if a[medio] == x:
            return medio, ops
        if a[medio] < x:
            izq = medio + 1
        else:
            der = medio - 1
    return -1, ops

def main():
    tamanos = [100, 1000, 10000, 100000, 500000]
    
    with open('resultados_python.csv', mode='w', newline='') as archivo:
        escritor = csv.writer(archivo)
        escritor.writerow(['lenguaje', 'n', 'algoritmo', 'escenario', 'repeticion', 'tiempo_ns', 'comparaciones'])

        for n in tamanos:
            datos = [i * 2 for i in range(n)]
            escenarios = [
                ("Inicio", datos[0]),
                ("Centro", datos[n // 2]),
                ("Final", datos[-1]),
                ("Ausente", -1)
            ]

            for nombre_esc, objetivo in escenarios:
                # Medición Búsqueda Lineal
                for rep in range(1, 31):
                    inicio = perf_counter_ns()
                    pos, ops = busqueda_lineal(datos, objetivo)
                    fin = perf_counter_ns()
                    escritor.writerow(['Python', n, 'Lineal', nombre_esc, rep, fin - inicio, ops])

                # Medición Búsqueda Binaria
                for rep in range(1, 31):
                    inicio = perf_counter_ns()
                    pos, ops = busqueda_binaria(datos, objetivo)
                    fin = perf_counter_ns()
                    escritor.writerow(['Python', n, 'Binaria', nombre_esc, rep, fin - inicio, ops])

if __name__ == '__main__':
    main()