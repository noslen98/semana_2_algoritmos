#include <iostream> // Para mostrar mensajes en consola
#include <vector>   // Para el arreglo dinámico vector<long long> (docente)
#include <chrono>   // Para el reloj de precisión
#include <fstream>  // Para guardar el archivo .csv

using namespace std;

// 1. Búsqueda Lineal (Código del docente)
int busquedaLineal(const vector<long long>& a, long long x, long long& ops) {
    ops = 0;
    for (size_t i = 0; i < a.size(); ++i) {
        ++ops;
        if (a[i] == x) return static_cast<int>(i);
    }
    return -1;
}

// 2. Búsqueda Binaria (Código del docente)
int busquedaBinaria(const vector<long long>& a, long long x, long long& ops) {
    int izq = 0, der = static_cast<int>(a.size()) - 1;
    ops = 0;
    while (izq <= der) {
        int medio = izq + (der - izq) / 2;
        ++ops;
        if (a[medio] == x) return medio;
        if (a[medio] < x) izq = medio + 1;
        else der = medio - 1;
    }
    return -1;
}

int main() {
    int tamanos[5] = {100, 1000, 10000, 100000, 500000};
    
    ofstream archivo("resultados_cpp.csv");
    archivo << "n,algoritmo,escenario,repeticion,tiempo_ns,comparaciones\n";

    for (int i = 0; i < 5; i++) {
        int n = tamanos[i];
        vector<long long> datos(n);
        for (int j = 0; j < n; j++) datos[j] = j * 2;

        // Los 4 valores a buscar: Inicio, Centro, Final, Ausente
        long long objetivos[4] = {datos[0], datos[n / 2], datos[n - 1], -1};
        const char* nombres[4] = {"Inicio", "Centro", "Final", "Ausente"};

        for (int e = 0; e < 4; e++) {
            for (int rep = 1; rep <= 30; rep++) {
                long long ops = 0;

                // Búsqueda Lineal
                auto t1 = chrono::high_resolution_clock::now();
                busquedaLineal(datos, objetivos[e], ops);
                auto t2 = chrono::high_resolution_clock::now();
                long long t_lineal = (t2 - t1).count();

                archivo << n << ",Lineal," << nombres[e] << "," << rep << "," << t_lineal << "," << ops << "\n";

                // Búsqueda Binaria
                ops = 0;
                t1 = chrono::high_resolution_clock::now();
                busquedaBinaria(datos, objetivos[e], ops);
                t2 = chrono::high_resolution_clock::now();
                long long t_binaria = (t2 - t1).count();

                archivo << n << ",Binaria," << nombres[e] << "," << rep << "," << t_binaria << "," << ops << "\n";
            }
        }
    }

    archivo.close();
    cout << "Listo resultados_cpp.csv" << endl;
    return 0;
}